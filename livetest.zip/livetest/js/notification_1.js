 
   
 
function addmsgs(type, msg){
 
$('#mail_count').html(msg);
 
}
 
function waitForMsgs(){
 
$.ajax({
type: "GET",
url: "mailajax.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(data){
   
addmsgs("new", data);
setTimeout(
waitForMsgs,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
addmsgs("error", textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsgs,
15000);
}
});
};
 
$(document).ready(function(){
 
waitForMsgs();
waitForMsg2s();
waitForMsg();
 waitForMsg2ss();
 

 
});
 
