<!DOCTYPE html>
<html>
<head>
<style>
#section {
    width:300px;
    float:left;
    padding:0px;	 	 
}

#nav {
    line-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:150px;
    float:right;
    padding:5px;	      
}
#nav2 {
    line-height:30px;
    background-color:yellow;
    height:300px;
    width:160px;
    clear:both;
   float:right;
          
}
#nav3 {
    line-height:30px;
    
    height:30px;
    width:160px;
    clear:both;
   float:right;
          
}

 
</style>
</head>
<body>
    <div style="width:100%;">

        <div style="width:70%">
<div id="nav">
London<br>
Paris<br>
Tokyo
</div>
 <div id="nav3"> <BR></div>
<div id="nav2">
London<br>
Paris<br>
Tokyo
</div>
</div>
        <div style="width:30%">
<div id="section">
<h2>London</h2>
<p>London is the capital city of England. It is the most populous city in the United Kingdom,
with a metropolitan area of over 13 million inhabitants.</p>
<p>Standing on the River Thames, London has been a major settlement for two millennia,
its history going back to its founding by the Romans, who named it Londinium.</p>
</div>

</div>
</div>
</body>
</html>
