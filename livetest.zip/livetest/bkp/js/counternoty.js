
function addcountss( count1){
 
$('#countnotys').html(count1);
 
}
function waitForMsg2ss(){
 
$.ajax({
type: "GET",
url: "notycounter.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(count1){
 
addcountss(count1);
setTimeout(
waitForMsg2ss,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
addmsgss(textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsg2ss,
15000);
}
});
};
 