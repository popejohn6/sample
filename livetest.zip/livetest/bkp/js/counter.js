
function addcounts( count){
 
$('#count').html(count);
 $('#count2').html(count);
  $('#count3').html(count);
}
function waitForMsg2s(){
 


$.ajax({
type: "GET",
url: "mailajaxcount.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(count){
   
addcounts(count);
setTimeout(
waitForMsg2s,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
addmsgs("error", textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsg2s,
15000);
}
});
};
 