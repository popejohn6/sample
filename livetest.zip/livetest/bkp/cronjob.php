<?php
file_get_contents('http://night-city.comeze.com/your-cron-job-file.php');
include 'config/dbconfig.php';
echo $obj->connect();
	    date_default_timezone_set('Asia/Kolkata');
       $date =date('m/d/Y');
	    $todos= $obj->selectcamp("todos","is_completed='' and todo_due_date = '$date'");
		while($tinc = mysql_fetch_array($todos))
		{
			
		$msg= 'Today Todo Due date';
	   $headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: support@livetest.com" . "\r\n";
$message = '<html>
<body>

<div style=" background-color:black;color:white;text-align:center;padding:5px;">
<h1>Today Todo Due date</h1>
</div>
<div style=" width:350px;float:left;padding:10px;">
<h2>Hello,'.$tinc["assign_user_id"].'</h2>
<p>Today '.$tinc["todo_title"].' Last day. </p>
</div>
<div style=" background-color:black;color:white;clear:both; text-align:center;padding:5px;">
Thank you
</div>
</body>
</html>
';

mail($tinc["assign_user_id"], 'Today Todo Due date', $message,$headers);

		}
		
        
  echo "Thank You";
       
        



?>

