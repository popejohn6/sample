<?php 
include 'config/dbconfig.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  $chat =$obj->select("chat");
  $finaluemails =explode("@",$row[1]);
   $noty= $obj->selectwhere("mail","status='unread'","uemail = '$finaluemails[0]'");

  

  $chat =$obj->select("chat");
  $count = 0;
  $alrt="";
  while ($row1 = mysql_fetch_array($noty)) {
      if($count <5)
      {
		  $uimail =explode("@",$row1[8]);
          $alrt.=" <a style='color: black;text-decoration: none;'> <div> <strong style='padding-left:05%'>".$uimail[0]."</strong><span style='padding-right:10%;' class='pull-right text-muted small'>".$row1[5]."</span><span style='font-size:12px'; > <br><span style='padding-left:05%'>".$row1[2]."</span> </span> </div></a></li> <li class='divider'></li>";                               
          $count = $count + 1;
          
      }
    

     
      
  }
  
  // $alrt.="uday</ul>";
  
   
     echo $alrt;
  
//echo json_encode(array("uday", $t));


   
   
   
       
}
else
{
    header("location:login.php");
}
?>
