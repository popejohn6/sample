 
   
 
function msgtask(types, msgs){
 
$('#taskcomplete').html(msgs);
 
}
 
function waitForMsgtask(){
 
$.ajax({
type: "GET",
url: "taskcomplete.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(datas){
   
msgtask("new", datas);
setTimeout(
waitForMsgtask,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
msgtask("error", textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsgtask,
15000);
}
});
};
 
 
 
