 
   
 
function addmsg(type, msg){
 
$('#mail_count').html(msg);
 
}
 
function waitForMsg(){
 
$.ajax({
type: "GET",
url: "mailajax.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(data){
   
addmsg("new", data);
setTimeout(
waitForMsg,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
addmsg("error", textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsg,
15000);
}
});
};
 
$(document).ready(function(){
 
waitForMsg();
waitForMsg2();
waitForMsgtask();

 
});
 
