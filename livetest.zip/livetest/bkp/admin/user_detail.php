<?php 
include '../config/dbconfig.php';
require_once 'config.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id='$ar'");
   // $pass=0;
  //  $id = '';
    $userencodeid=$_GET['id'];
  $row = mysql_fetch_array($tmp);
 // $chat =$obj->select("chat");
  // $notification= $obj->selectwhere("noty","uemail='$row[3]'");
    //$todos= $obj->selectcamp("todos","assign_user_id='$row[3]'");
    $letter="";
    $where ="";
    $campid="";
    $todoid="";
     $nr="";
    if(isset($_REQUEST['id']))
    {
           
                                    
        if( isset($_GET['id']) && !empty( $_GET['id'] ) ){
            $id = urldecode($_GET['id']);
            $todoid = encryptor('decrypt', $id);




        }   
                        
                                      
       // $todoid =$_REQUEST['id'];
        $where ="id ='$todoid'";
         $userdata= $obj->selectwhere("user",$where);
          $userdetail = mysql_fetch_array($userdata);
          
            
    }
    if($userdetail[0]!="")
    {
 
   if(isset($_REQUEST['tododelete']))
  {    
      $ins = "id='$userdetail[0]'";

      $usr= $obj->deleteData("user",$ins);
      $msg="User delete sucsessfuly";
          $msgen = urlencode(encryptor('encrypt', $msg));  
         
      header("location:viewuser.php?msg=$msgen");
        exit;
  }
  
  

  
  if(isset($_REQUEST['todos']))
  {
  $type=$_REQUEST['type'];
       $fname=$_REQUEST['fname'];
        $sname=$_REQUEST['lname'];
        $email=$_REQUEST['email'];
        //$image=$_REQUEST['img'];
        $password=$_REQUEST['password'];
       
        $target_dir = "upload/"; 
        $img="";
    $target_file = $target_dir . basename($_FILES["img"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
   
    if($_FILES['img']["name"]!="")
    {
         $img =basename($_FILES["img"]["name"]);
    if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
       
    } else {
       
    }
    }
 else {
        $img=$userdetail['image'];
    }
    $image=basename( $_FILES["img"]["name"],".jpg"); // used to store the filename in a variable
    
        $ins = "fname='$fname',lname='$sname',email='$email',image='$img',password='$password',type='$type' where id='$userdetail[0]'";
      $usr= $obj->updatecamp("user",$ins);
      
      
       $msg="User Update sucsessfuly";
              $msgen = urlencode(encryptor('encrypt', $msg));  
               header("location:user_detail.php?id=$userencodeid&msg=$msgen");
    
           
       
        
  }
  
  
   
?>
<html lang="en">

<head>
    <style>
 time.icon
{
  font-size: 1em; /* change icon size */
  display: inline-block;
  position: relative;
  width: 7em;
  height: 7em;
  background-color: #fff;
  border-radius: 0.6em;
  box-shadow: 0 1px 0 #bdbdbd, 0 2px 0 #fff, 0 3px 0 #bdbdbd, 0 4px 0 #fff, 0 5px 0 #bdbdbd, 0 0 0 1px #bdbdbd;
  overflow: hidden;
}
time.icon strong
{
  position: absolute;
  top: 0;
  padding: 0.4em 0;
  color: #fff;
  background-color: #fd9f1b;
  border-bottom: 1px dashed #f37302;
  box-shadow: 0 2px 0 #fd9f1b;
}
time.icon em
{
  position: absolute;
  bottom: 0.3em;
  color: #fd9f1b;
}
time.icon span
{
  font-size: 2.8em;
  letter-spacing: -0.05em;
  padding-top: 0.8em;
  color: #2f2f2f;
}
time.icon *
{
  display: block;
  width: 100%;
  font-size: 1em;
  font-weight: bold;
  font-style: normal;
  text-align: center;
}

#nav {
    line-height:30px;
    background-color:#eeeeee;
    height:350px;
    width:300px;
    float:right;
    padding:5px;	      
}
#nav2 {
    line-height:30px;
      background-color:#eeeeee;
    height:350px;
    width:300px;
    clear:both;
   float:right;
          
}
#nav3 {
    line-height:30px;
    
    height:10px;
    width:160px;
    clear:both;
   float:right;
          
}


 
</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>OTM</title>
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
     <link href="dist/css/timeline.css" rel="stylesheet">
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
    
      <link href="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
     <link href="dist/css/table.css" rel="stylesheet">
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="dist/js/jslib.js"></script>
    <script type="text/javascript" src="js/notification.js">
 
</script>
   
 
<?php // <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> ?>

<link rel="stylesheet" href="dist/css/jquery-ui.css" />   
    <script src="js/jquery-ui.js"></script>
 
        <!--pqSelect dependencies-->
        <script type="text/javascript" src="js/notification.js"> </script>
    <script type="text/javascript" src="js/campaign.js"> </script>
    <script type="text/javascript" src="js/counter.js"></script>
    
     <link rel="stylesheet" href="pqselect.dev.css" />    
        <script src = "pqselect.dev.js"></script>
        
    
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  
  });
  </script>

</head>
<body>

    <form action="user_detail.php?id=<?php echo $_GET['id']?>" method="post">
                            <!-- Modal -->
                            <div class="modal fade" id="tododelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Delete User</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                              
                                                <div> Are You sure you want to delete ?</div></td>
                                                 
                                                </center>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="tododelete" value="Delete">
                                        </div>
                                        
                                    </div>
                                    
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                             </form>
    
    
    <form action="user_detail.php?id=<?php echo $_GET['id']?>" method="post" enctype="multipart/form-data" id="commentForm">
                            <!-- Modal -->
                            <div class="modal fade" id="todos" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Edit User</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                              
                                                <div title="First Name"> <input type="text" name="fname" class="form-control" value="<?php echo $userdetail['fname'] ;?>" placeholder="Enter First Name " data-rule-required="true"  data-msg-required="Please Enter First Name" style="margin: 10px;"></div></td>
                                                <div title="Last Name"> <input type="text"   class="form-control" value="<?php echo $userdetail['lname'] ;?>"  name="lname" placeholder="Enter Last Name "   data-rule-required="true"  data-msg-required="Please Enter Last Name" style="margin: 05px;"></div></td>
                                                 <div title="Email Address"> <input type="email"   class="form-control" value="<?php echo $userdetail['email'] ;?>"  name="email" placeholder="Enter Email Address "   data-rule-required="true" data-rule-email="true" data-msg-required="Please Enter User Email Address" data-msg-email="Please enter a valid email address" style="margin: 05px;"></div></td>
                                                 <div title="Password"> <input type="password"   class="form-control" value="<?php echo $userdetail['password'] ;?>"  name="password" placeholder="Enter Password "   data-rule-required="true"  data-msg-required="Please Enter Password" style="margin: 05px;"></div></td>
                                                <div title="Image">
                                                    <input type="file" name="img">
                                                 </div>
                                                <div title="User Type">User Type :
                                                   
                                                    <input type="radio" name="type" value="user"  <?php if($userdetail['type']=="user"){ echo "checked='true'";} ?> > User
                                                    <input type="radio" name="type" value="editor"  <?php if($userdetail['type']=="editor"){ echo "checked='true'";} ?>>  Editor
                                                </div>
                                            
                                               </center>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="todos" value="Update">
                                        </div>
                                        
                                    </div>
                                    
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                             </form>
    
    
    
   
    
    
   
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="font-family: fantasy;font-size: 50px;color: #0075b0"><img src="logo.png" width="160px" height="30px"></img></a>
				
            </div>
            <!-- /.navbar-header -->

            <?php include 'header.php'; ?>
            <!-- /.navbar-top-links -->

            <?php include 'menu.php'; ?>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                   <?php 
                                     $msg="";
                                    if( isset($_GET['msg']) && !empty( $_GET['msg'] ) ){
                                        $msg = urldecode($_GET['msg']);
                                        $msg = encryptor('decrypt', $msg);
                                        ?>
                                          <script>
                                        setTimeout(function() {
                                        $('#mydiv').slideUp();
                                    }, 2000);
                                        </script>
                                        <div id="mydiv" class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                               <?php echo $msg; ?>
                                         </div>
                                         <?php
                                    }   
                        
                                    ?>     
           
                <div class="col-lg-12">
                    <h1 class="page-header heading"><?php echo $userdetail["fname"]." ".$userdetail["lname"];?> 
                        
                        <button class="btn btn-success  btn-circle btn-lg"  title="Edit User" data-toggle='modal' data-target='#todos' type="button"><i class="fa  fa-edit"></i>
</button>
                          <button class="btn btn-success  btn-circle btn-lg"  title="Delete User" data-toggle='modal' data-target='#tododelete' type="button"><i class="fa  fa-trash-o"></i>
</button>
                     
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <!-- /.row -->
            
                
                        
                     
            <div class="row">
                
               
             <div >
                 
           
 
     
                 <div style="text-align: center">
                     <div style="padding-bottom: 10px;padding-top: 10px;">
					 <?php if($userdetail['image'] != "")
					 {
						 ?> <img style="border-radius: 60%;" height="200" width="200" src="upload/<?php echo $userdetail['image'];?>"><?php 
					 }	
					else{
						?><img style="border-radius: 60%;" height="200" width="200" src="upload/ni.png"><?php 
					}?>
					 </div> 
                        <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px">  First Name : <?php echo $userdetail['fname'];?></div>
    <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px"> Last Name : <?php echo $userdetail['lname'];?></div>
 
    
    <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;padding-top: 10px;"> Email : <?php echo $userdetail['email'];?></div>
    
   <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;padding-top: 10px;"> Password : <?php echo $userdetail['password'];?></div>
 <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;padding-top: 10px;"> Type  : <?php  if($userdetail['type']=="user"){ echo "User";}else {echo "Editor";};?></div>

</div>
                 <hr>
                
                
                 
            </div>
             
        </div>
     </div>
    
    </div>
    
   
  <?php //  <script src="bower_components/jquery/dist/jquery.min.js"></script> ?>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
  <script src="bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
   
    <script src="../dist/jquery.validate.js"></script>
     <script src="dist/js/sb-admin-2.js"></script>
      <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
        $("#commentForm").validate();
    });
    </script>
     <script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>
</body>

</html>

<?php
}
else
{
    echo "404 page not found";
}
}
else
{
    header("location:login.php");
}
?>
    