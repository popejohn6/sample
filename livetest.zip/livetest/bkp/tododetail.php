<?php 
include 'config/dbconfig.php';
require_once 'config.php';

 $obj->connect();
session_start();
if($_SESSION['aid'] != '')
{
   $ar = $_SESSION['aid'];
    $tmp= $obj->selectwhere("user","id='$ar'");
   // $pass=0;
  //  $id = '';
  $row = mysql_fetch_array($tmp);
 // $chat =$obj->select("chat");
   $notification= $obj->selectwhere("noty","uemail='$row[3]'");
    $todos= $obj->selectcamp("todos","assign_user_id='$row[3]'");
    $letter="";
    $where ="";
    $campid="";
    
    if($_REQUEST['id'])
        {
         if( isset($_GET['id']) && !empty( $_GET['id'] ) ){
        $ids = urldecode($_GET['id']);
        $todoid = encryptor('decrypt', $ids);
        }

            
        }
       
        
    if(isset($_REQUEST['id']))
    {
        
        $where ="id ='$todoid'";
         $tododata= $obj->selectwhere("todos",$where);
          $tododetail = mysql_fetch_array($tododata);
          $campdetails = $obj->selectwhere("tasking","id='$tododetail[1]'");
          $campdetail =mysql_fetch_array($campdetails);
          
        
    }
        
  if($campdetail)
  {
    
    if($tododetail['is_completed'] =="")
    {
       $username="";
    $campdata ="blank";
     $user = $obj->select("user");
 
     $letter ="";
   
 
   

  
  if(isset($_REQUEST['todos']))
  {
      $tname=$_REQUEST['tname'];
       $tedate=$_REQUEST['tddate'];
        $tcomment=$_REQUEST['tcomment'];
        $tuser=$_REQUEST['tuser'];
        $creator =$row[2];
        date_default_timezone_set('Asia/Kolkata');
         $time=time();
        $ctime= date('d-m-Y');
       
       
       $instodos = "'','$campdetail[0]','$row[1]','$tuser','$tname','$tcomment','$tedate','','','','$ctime',''";

      $usr= $obj->insert_user("todos",$instodos);
	  
	  $headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: support@livetest.com" . "\r\n";
$message = '<html>
<body>

<div style=" background-color:black;color:white;text-align:center;padding:5px;">
<h1>New Todo Create</h1>
</div>
<div style=" width:350px;float:left;padding:10px;">
<h2>Hello,</h2>
<p><b>Added you todo '.$tname.'.</b></p>

</div>
<div style=" background-color:black;color:white;clear:both; text-align:center;padding:5px;">
Thank you
</div>
</body>
</html>
';

mail($tuser, 'New Todo Create', $message,$headers);

	  
	  
      $ctimeday= date('d-m-Y');
        $notydatatodo ="'','New Todo Create by $creator Todo Title : $tname Campaign name : $campdetail[2]','unread','$ctimeday','$tuser',''";
         $usrnotytodo= $obj->insert_noty("noty",$notydatatodo);
           
          $msg="Todo Edit sucsessfuly";
          $msgen = urlencode(encryptor('encrypt', $msg));  
         $cid = urlencode(encryptor('encrypt', $_GET['id']));  
      header("location:tododetail.php?id=$cid&msg=$msgen");
        exit;   
       
        
  }
  
   if(isset($_REQUEST['tododelete']))
  {    
      $ins = "id='$todoid'";

      $usr= $obj->deleteData("todos",$ins);
      $msg="Todo delete sucsessfuly";
          $msgen = urlencode(encryptor('encrypt', $msg));  
         
      header("location:todos.php?msg=$msgen");
        exit;
  }
  
  // $camptodo= $obj->selectwhere("tasking","cid='$campdetail[0]'");
   
?>
<html lang="en">

<head>
    <style>
 time.icon
{
  font-size: 1em; /* change icon size */
  display: inline-block;
  position: relative;
  width: 7em;
  height: 7em;
  background-color: #fff;
  border-radius: 0.6em;
  box-shadow: 0 1px 0 #bdbdbd, 0 2px 0 #fff, 0 3px 0 #bdbdbd, 0 4px 0 #fff, 0 5px 0 #bdbdbd, 0 0 0 1px #bdbdbd;
  overflow: hidden;
}
time.icon strong
{
  position: absolute;
  top: 0;
  padding: 0.4em 0;
  color: #fff;
  background-color: #fd9f1b;
  border-bottom: 1px dashed #f37302;
  box-shadow: 0 2px 0 #fd9f1b;
}
time.icon em
{
  position: absolute;
  bottom: 0.3em;
  color: #fd9f1b;
}
time.icon span
{
  font-size: 2.8em;
  letter-spacing: -0.05em;
  padding-top: 0.8em;
  color: #2f2f2f;
}
time.icon *
{
  display: block;
  width: 100%;
  font-size: 1em;
  font-weight: bold;
  font-style: normal;
  text-align: center;
}


 
</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>OTM</title>
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
     <link href="dist/css/timeline.css" rel="stylesheet">
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
     <link href="bower_components/morrisjs/morris.css" rel="stylesheet">
      <link href="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
     <link href="dist/css/table.css" rel="stylesheet">
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="dist/js/jslib.js"></script>
    <script type="text/javascript" src="js/notification.js">
 
</script>
   
 
<?php // <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> ?>

<link rel="stylesheet" href="dist/css/jquery-ui.css" />   
    <script src="js/jquery-ui.js"></script>
 
        <!--pqSelect dependencies-->
          <script type="text/javascript" src="js/notification_1.js"> </script>
    <script type="text/javascript" src="js/counter.js"></script>
    <script type="text/javascript" src="js/counternoty.js"></script>
    
     <link rel="stylesheet" href="pqselect.dev.css" />    
        <script src = "pqselect.dev.js"></script>
        
    <?php  $tempDate = $campdetail['edate'];
 
	$dates = date('m', strtotime( $tempDate))."/".date('d', strtotime( $tempDate))."/".date('Y', strtotime( $tempDate));

	?>
    <script>
  $(function() {
    $( "#datepicker" ).datepicker({ minDate: 0 });
    $( "#datepicker2" ).datepicker({ minDate: 0 });
    $( "#datepicker3" ).datepicker({ minDate: 0,maxDate: new Date(<?php echo json_encode($dates) ?>)});
  });
  </script>
  <script>
var btns = "";
var all="All";
var letters = "abcdefghijklmnopqrstuvwxyz";
var letterArray = letters.split("");
for(var i = 0; i < 26; i++){
    var letter = letterArray.shift();
    btns += '<button class="btn btn-outline btn-success" onclick="alphabetSearch(\''+letter+'\');">'+letter+'</button>';
}
 btns += '<button class="btn btn-outline btn-success" onclick="alphabetSearch(\''+all+'\');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+all+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>';
function alphabetSearch(let){
    window.location = "campaign.php?letter="+let;
}
</script>
<script src="dist/jquery.validate.js"></script>
<script>
	$(document).ready(function() {
		$("#commentForm").validate();
                $("#commentForm1").validate();
               
		 
	});
	</script>
</head>
<body>

<form action="tododetail.php?id=<?php echo $_GET['id']?>" method="post">
                            <!-- Modal -->
                            <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Delete Todo's</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                              
                                                <div> Are You sure you want to delete ?</div> 
                                                 
                                                </center>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="tododelete" value="Delete">
                                        </div>
                                        
                                    </div>
                                    
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                             </form>
    
    <form action="updatetodosedit.php?id=<?php echo$tododetail[0]?>" method="post" id="commentForm">
                            <!-- Modal -->
                            <div class="modal fade" id="todos" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Edit Todo's</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                              
                                                <div> <input type="text" name="tname" class="form-control" value="<?php echo $tododetail[4]; ?>"  placeholder="Enter Todo's Title " data-rule-required="true"  data-msg-required="Please Enter Todo Title" style="margin: 10px;"></div></td>
                                                <div> <input type="text" id="datepicker3"  class="form-control" value="<?php echo $tododetail[6]; ?>" name="tddate" placeholder="Enter Due Date " readonly="true"  required="true" style="margin: 05px;"></div></td>
                                           
                                                <div>   <select  class="form-control"   name="tuser" style="margin: 10px;" data-rule-required="true"  data-msg-required="Please Select User ">            
                                                        <option value="">Select User</option>
                                                    <?php
                                                     $usercamps = explode(',', $campdetail[1]);
        
                                                        foreach ($usercamps as $username) {
                                                             if($username !=  "" && $tododetail[3]== $username)
                                                             {
                                                            $userdata.="<option selected value='".$username."'>".$username."</option>";
                                                            break;
                                                        }
                                                         if($username != "")
                                                         {
                                                        $userdata.="<option  value='".$username."'>".$username."</option>";
                                                         }
                                                             }
                                                    echo $userdata; ?>
                                                   

                                               </select></div>
                                   
                                             
                                 
                                 
                                            <div > <textarea class="form-control"  name="tcomment"  placeholder="Description " cols="22" data-rule-required="true"  data-msg-required="Please Enter Description "><?php echo $tododetail[5];?></textarea></div>
                                 
                                       
                                            </center>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="todos" value="Update">
                                        </div>
                                        
                                    </div>
                                    
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                             </form>
  
    
    
    <form action="todoupdatereassign.php?id=<?php echo$tododetail[0]?>" method="post" id="commentForm1">
                            <!-- Modal -->
                            <div class="modal fade" id="reassign" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Reassign Todo's</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                              
                                                
                                                <div>   <select  class="form-control"   name="tuser" style="margin: 10px;" data-rule-required="true"  data-msg-required="Please Select User ">            
                                                        <option value="">Select User</option>
                                                    <?php
                                                     $usercamps = explode(',', $campdetail[1]);
        
                                                        foreach ($usercamps as $username) {
                                                             if($username !=  "" && $username != $row[3])
                                                             {
                                                                  
                                                            $userdatas.="<option value='".$username."'>".$username."</option>";
                                                            
                                                        }
                                                         
                                                             }
                                                    echo $userdatas; ?>
                                                   

                                               </select></div>
                                            </center>
                                   
                                        
                                    </div>
                                    
                                <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="todos" value="Reassign">
                                        </div>
                                </div>
                                </div>
                            </div>
                             </form>
  

    <form action="updatetodos.php" method="post">
                            <!-- Modal -->
                            <div class="modal fade" id="complete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Conform</h4>
                                        </div>
                                        <div class="modal-body">
                                            <center>
                                                <input type="text" name="id" value="<?php echo$tododetail[0]?>" hidden="true">
                                                Are you Complete This Todo's ?
                                            </center>
                                   
                                        
                                    </div>
                                    
                                <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                                            
                                            <input type="submit" class="btn btn-primary" name="complete" value="Yes">
                                        </div>
                                </div>
                                </div>
                            </div>
                             </form>
  
   
    
    
    
   
    
    
   
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="font-family: fantasy;font-size: 50px;color: #0075b0"><img src="logo.png" width="160px" height="30px"></img></a>
				
            </div>
            <!-- /.navbar-header -->

            <?php include 'header.php'; ?>
            <!-- /.navbar-top-links -->

            <?php include 'menu.php'; ?>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header heading"><?php echo $tododetail['todo_title']."&nbsp;<span style='font-size:18px;color:black;'>[".$campdetail[2]."]</span>";?> 
                        <?php  
                            if($row[6] == "editor")
                            {
                               
                        ?>
                        <button class="btn btn-success  btn-circle btn-lg" title="Edit" data-toggle='modal' data-target='#todos' type="button"><i class="fa  fa-edit"></i>
</button>
                        <button class="btn btn-success  btn-circle btn-lg" title="Edit" data-toggle='modal' data-target='#delete' type="button"><i class="fa  fa-trash-o"></i>
</button>
                    <?php
                            } 
                            
                        if($tododetail[3]==$row[3])
                        {
                            ?>
                        
                        <a class="btn btn-success  btn-circle btn-lg" data-toggle='modal' data-target='#complete' href="todocomplate" title="Complate"><i style="padding-top: 5px;" class="fa  fa-check"></i></a>
                        <button class="btn btn-success  btn-circle btn-lg" data-toggle='modal' data-target='#reassign' type="button" title="Reassign"><i class="fa  fa-sign-out "></i></button>
                        <?php
                        }
                        ?>
                        
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <!-- /.row -->
            
                
                        
                     
            <div class="row">
                
                <?php 
                                     $msg="";
                                    if( isset($_GET['msg']) && !empty( $_GET['msg'] ) ){
                                        $msg = urldecode($_GET['msg']);
                                        $msg = encryptor('decrypt', $msg);
                                        ?>
                                          <script>
                                        setTimeout(function() {
                                        $('#mydiv').slideUp();
                                        },2000);
                                        </script>
                                        <div id="mydiv" class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                               <?php echo $msg; ?>
                                         </div>
                                         <?php
                                    }   
                        
                                    ?>     
             <div >
                 
           
 
  
 
                 <div style="text-align: center">

    <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px">Campaign Name : <?php echo $campdetail['name'];?></div>
    <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px">Todo's Name : <?php echo $tododetail[4];?></div>
    <div> 
   
    <time   class="icon">
  <em>
   <?php 
    $tempDate = $tododetail['todo_due_date'];;
     echo "<b style='color: black;'>".date('d', strtotime( $tempDate))."</b>";
    echo date('l', strtotime( $tempDate))."<br>";
    echo date('M', strtotime( $tempDate))."-".date('Y', strtotime( $tempDate));
    ?>
  </em>
  <strong><?php 
   
    echo "Due Date";
    ?></strong>
        
        
 
    </time>&nbsp;&nbsp;&nbsp;&nbsp;
        
           
        </div>
    
          <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;padding-top: 10px"> Assign User  : <?php echo $tododetail[3];?></div>
        <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;"> Detail :   <?php echo $tododetail['todo_description'];?></div>
         <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;"> Create By  : <?php echo $tododetail[2];?></div>
          <div style="font-size: 20px;color: grey; font-family: sans-serif;padding-bottom: 10px;"> Status : <?php if($tododetail['is_completed'] == ""){echo "Open";}else{ echo "Close";};?></div>
 
          
       
</div>
               
                 
            </div>
             
        </div>
     </div>
    
   
  <?php //  <script src="bower_components/jquery/dist/jquery.min.js"></script> ?>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
  <script src="bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    
   
     <script src="dist/js/sb-admin-2.js"></script>
      <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>
     <script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>
</body>

</html>

<?php
}
else
{
     header("location:index.php");
}

  }
   else {
    echo '404 page not found';
}
  

}
else
{
    header("location:login.php");
}
?>
    