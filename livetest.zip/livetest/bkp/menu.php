<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <div>
                                <span class="navbar-brand" style="padding: 25px 15px;"> Welcome <?php echo $row['fname']; ?> </span>
                                </div>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        
                       
                        <li>
                            <a href="campaign.php"><i class="fa fa-tasks fa-fw"></i> Campaign</a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                        
                        
                        <li>
                            <a href="todos.php"><i class="fa fa-bell fa-fw"></i> ToDo's</a>
                           
                          
                        </li>
                        <li>
                            <a href="calendar.php"><i class="fa fa-calendar fa-fw"></i> Calender</a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="mail.php"><i class="fa fa-envelope fa-fw"></i> Mail</a>
                        </li>
                        
                        
                        
                      
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>