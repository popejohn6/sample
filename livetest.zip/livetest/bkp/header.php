<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-77423050-1', 'auto');
  ga('send', 'pageview');
</script>
<ul class="nav navbar-top-links navbar-right">
                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i>  <span style="color:red; " id="count"></span>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <a href="mailunread.php"><span style="color:red;padding-left: 68%;">Clear All </span></a>
                         <span id="mail_count"></span> 
                      
                        
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="mail.php">
                                <strong>Read All Mail</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
        
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
               
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i>  <span style="color:red; " id="countnotys"></span>  <i class="fa fa-caret-down"> </i>


                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                         <a href="notyunread.php"><span style="color:red;padding-left: 70%;">Clear All </span></a>
                       <span id="notification_count"></span>
                        
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="index.php">
                                <strong>See All Alerts</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-alerts -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                       <?php if($row['image']=="")
					   {
						  ?>  <img style="width:50px;height:50px;padding-bottom: 0px" alt="<?php echo $row['fname']?>" src="admin/upload/ni.png"/> <?php
					   } else
					   {
						  ?><img style="width:50px;height:50px;padding-bottom: 0px" alt="<?php echo $row['fname']?>" src="admin/upload/<?php echo $row['image']?>"/>  <?php 
					   }						   
					   ?>
                        
                    
                        </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-user fa-fw"></i> <?php echo $row['fname']; ?> Profile</a>
                        </li>
                        
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>