<?php

session_start();
$_SESSION['aid']="";
header("location:login.php");

?>