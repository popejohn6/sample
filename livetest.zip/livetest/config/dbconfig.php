<?php
class connection
 {
	 
	 
	 function connect()
	 {
		 $ssServerName = "localhost";//Your server name
	     $ssUserName = "root";//root
		 $ssPassword = "";//database password
	     $ssDbname = "bca";//database name here
		$con = mysql_connect($ssServerName,$ssUserName,$ssPassword);
		if (!$con)
		{
			die('Could not connect: ' . mysql_error());
		}
                else
               
		mysql_select_db($ssDbname,$con);
	 }
	 function update_data($ssTable,$ssField,$ssValue)
	 {
		$sql = "UPDATE  $ssTable SET $ssField = '".$ssValue."' ";
		mysql_query($sql);
	 }
         function updatecamp($ssTable,$ssValue)
	 {
		$sql = "UPDATE  $ssTable SET $ssValue ";
		mysql_query($sql);
                
                return $sql;
	 }
         function update_data_mail($ssTable,$ssField,$ssValue)
	 {
		$sql = "UPDATE  $ssTable SET $ssField WHERE $ssValue ";
		mysql_query($sql);
	 }
	 function fetch_data($result)
	 {
		while($row = mysql_fetch_array($result))
		{
		  $arr[] = $row ;
		}
		return $arr;  
	 }
	
          function select($ssTable)
	 {
		$ssQuery = "SELECT * FROM $ssTable ORDER BY id DESC";
		$result = mysql_query($ssQuery); 
		
		return $result;  
	 }
          function selectlike($ssTable,$q)
	 {
		$ssQuery = "SELECT * FROM $ssTable $q";
		$result = mysql_query($ssQuery); 
		
		return $result;  
	 }
          function selecttask($ssTable,$char)
	 {
		$ssQuery = "SELECT * FROM $ssTable Where udi LIKE '$char%'";
		$result = mysql_query($ssQuery); 
		
		return $result;  
	 }
         
         function selectcamp($ssTable,$wr)
	 {
		$ssQuery = "SELECT * FROM $ssTable WHERE $wr ORDER BY id DESC";
		$result = mysql_query($ssQuery); 
		
		return $result;  
	 }
          public function insert_user($ssTableName,$data)
	 {
           
		$ssQuery = '';
		
		$ssQuery = "INSERT INTO $ssTableName VALUES ($data)";
		mysql_query($ssQuery);
		return $ssQuery;
	 }
           public function inserts($ssTableName,$data)
	 {
           
		$ssQuery = '';
		
		$ssQuery = "INSERT INTO $ssTableName VALUES ($data)";
		mysql_query($ssQuery);
		return $ssQuery;
	 }
         public function insert_noty($ssTableName,$data)
	 {
           
		$ssQuery = '';
		
		$ssQuery = "INSERT INTO $ssTableName VALUES ($data)";
		mysql_query($ssQuery);
		return $ssQuery;
	 }
	 public function insert_data($ssTableName,$email,$time,$msg,$img)
	 {
            if(img =="")
            {
                $image ="../upload/PicsArt_12-09-03.20.15.jpg";
            }
            else {
                    $image =$img;
            }
		$ssQuery = '';
		
		$ssQuery = "INSERT INTO $ssTableName VALUES ('','".$email."','".$time."','".$msg."','".$image."','0')";
		mysql_query($ssQuery);
		return $ssQuery;
	 }
	 function close($con)
	 {
		 mysql_close($con);
	 }
	 function selectedit($ssTable ,$ssField='')
	 {
             $field='';
             if($ssField!='')
             {
                 $field='WHERE ';
                 foreach ($ssField as $f => $v) {
                     $field.=$f." = "."'".$v."'"." AND ";
                 }
             }
             
                $field1 = rtrim($field," AND ");
		 $ssQuery = "SELECT * FROM $ssTable $field1  ";
		$result = mysql_query($ssQuery); 
		
		return $result;  
	 }
         
          public function insert_mail($ssTableName,$user,$title,$msg,$file,$time,$ip,$sender)
	 {
           
		$ssQuery = '';
		
		$ssQuery = "INSERT INTO $ssTableName VALUES ('','".$user."','".$title."','".$msg."','".$file."','".$time."','".$ip."','unread','".$sender."')";
		mysql_query($ssQuery);
		return $ssQuery;
	 }
          function selectwhere($ssTable ,$ssField)
	 {
             $ssQuery = "SELECT * FROM $ssTable WHERE $ssField ORDER BY id DESC ";
            $result = mysql_query($ssQuery); 
            return $result;  
	 }
          function selecttest($ssTable ,$ssField)
	 {
             $ssQuery = "SELECT * FROM $ssTable WHERE $ssField ORDER BY id DESC ";
            $result = mysql_query($ssQuery); 
            return $ssQuery;  
	 }
          function selectwhere_noty($ssTable ,$ssField)
	 {
            
             
            
		 $ssQuery = "SELECT * FROM $ssTable WHERE $ssField ORDER BY id DESC ";
		$result = mysql_query($ssQuery); 
		
		return $ssQuery;  
	 }
	  function update($ssTable_name,$asUpdateFields,$ssConField,$snConFieldValue)
	{
		
		$ssQuery="UPDATE $ssTable_name SET ";
		foreach ( $asUpdateFields as $ssFieldName => $ssFieldValue )
			$ssQuery .=  $ssFieldName."= '".$ssFieldValue."',";

		$ssQuery = substr($ssQuery,0,strlen($ssQuery)-1);
		$ssQuery .=" WHERE $ssConField = '$snConFieldValue' ";
		mysql_query($ssQuery);
		return true;
		//return $this->amResult ;

	}
	 function updatedata($ssTable_name,$asUpdateFields)
	{
		
		$ssQuery="UPDATE $ssTable_name SET $asUpdateFields";
	
		mysql_query($ssQuery);
		return $ssQuery;
		//return $this->amResult ;

	}
	 function delete($sql) {
        $sql = trim($sql);
        $result = mysql_query($sql);
        if (!$result) {
            return 0;
        } else {
            return $result;
        }
    }

    function deleteData($table, $where) {
        $sql = "Delete From " . $table." where " . $where;
       
            
       
		$sql = trim($sql);
        $result = mysql_query($sql);
		if (!$result) {
            return 0;
        } else {
            return $result;
        }
    }
    
  
	 
 }
 $obj = new connection();
?>