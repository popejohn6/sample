<?php 
include '../config/dbconfig.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = $_REQUEST['id'];
  $row = mysql_fetch_array($tmp);
  
  
$campdata= $obj->selectwhere("user","email='$id'");
$campdetail = mysql_fetch_array($campdata);

if($campdetail[3]==$id)
{
	echo "Sorry,email address id already avalible <br> <input type='hidden' name='em' value='1'>";
}
else
{
	echo "";
	
}

   
       
}
else
{
    header("location:login.php");
}
?>
