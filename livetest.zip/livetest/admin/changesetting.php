<?php 
include 'config/dbconfig.php';
require_once 'config.php';

 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  
   
   if(isset($_REQUEST['profile']))
  {
      
      $name=$_REQUEST['name'];
      $cpass=$_REQUEST['password'];
      
      $msg="";
       $file="";
      
           if($row['password']==$cpass)
           {
                if($_FILES['img']["name"]!="")
                {
                        $target_dir = "upload/"; 
                     $target_file = $target_dir . basename($_FILES["img"]["name"]);
                       $file =basename($_FILES["img"]["name"]);
                         if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {

                         } else {

                         }
                }
                else
                {
                    $file=$row['image'];
                }
            
               $ins = "name='$name',image='$file' where id='$ar'";
                $usr= $obj->updatecamp("admin",$ins);
                $msg="Profile change sucsessfuly";
              $msgen = urlencode(encryptor('encrypt', $msg));  
               header("location:setting.php?msg=$msgen");
               exit;
               
           }
           else
           {
               $msg="Password not match please try again";
              $msgen = urlencode(encryptor('encrypt', $msg));  
               header("location:setting.php?msg=$msgen");
           }
        
       
     
        
       
  
  
  }
       
}
else
{
    header("location:login.php");
}
?>
