<!DOCTYPE html>

<?php
include '../config/dbconfig.php';
echo $obj->connect();
if(isset($_REQUEST['submit']))
{
    $ar =array();
    $ar["email"] = $_REQUEST['email'];
    $ar["password"] = $_REQUEST['password'];
    $tmp= $obj->selectedit("admin",$ar);
    $pass=0;
    $id = '';
	$msg="";
    while($row = mysql_fetch_array($tmp))
    {
        $pass=1;
        $id =$row['id'];
    }
    if($pass==1)
    {
       if (isset($_POST['remember']) && $_POST['remember'] == 'remember') {
    /*
     * Set Cookie from here for one hour
     * */
		
	
    setcookie("email", $_REQUEST['email'], time()+(60*60*8));
    setcookie("password", $_REQUEST['password'], time()+(60*60*8));  /* expire in 1 hour */
  } else {
    /**
     * Following code will unset the cookie
     * it set cookie 1 sec back to current Unix time
     * so that it will invalid
     * */
    setcookie("email", "",  time()+(60*60*8));
    setcookie("password", "",  time()+(60*60*8));
  }

        header("location:index.php");
        session_start();
        $_SESSION['id']=$id;
    }
    else
    {
        
    $msg="<span style='color:red;font-size:20px;'>Id or password wrong</span>";
 
    }

}



?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

  

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
  
        
        
        <script src="lib/jquery.1.11.min.js"></script>
       
        <script src="js/Lobibox.js"></script>
        <script src="demo/demo.js"></script>
  <style type="text/css">
body {
background-color: #f4f4f4;
color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 16px;
line-height: 1.5em;
}
a { text-decoration: none; }
h1 { font-size: 1em; }
h1, p {
margin-bottom: 10px;
}
strong {
font-weight: bold;
}
.uppercase { text-transform: uppercase; }

/* ---------- LOGIN ---------- */
#login {
margin: 50px auto;
width: 300px;
}
form fieldset input[type="email"], input[type="password"] {
background-color: #e5e5e5;
border: none;
border-radius: 3px;
-moz-border-radius: 3px;
-webkit-border-radius: 3px;
color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 280px;
-webkit-appearance:none;
}
form fieldset input[type="submit"] {
background-color: #008dde;
border: none;
border-radius: 3px;
-moz-border-radius: 3px;
-webkit-border-radius: 3px;
color: #f4f4f4;
cursor: pointer;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
height: 50px;
text-transform: uppercase;
width: 300px;
-webkit-appearance:none;
}
form fieldset a {
color: #5a5656;
font-size: 10px;
}
  </style>
</head>

<body>
    <div style="text-align:center"> <img src="logo.png" width="360px" height="50px"></img> </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Login</h3>
						
                    </div><br>
					<center><?php if(isset($msg)){
							echo $msg;
						}?>
						</center>
                    <div  id="login">
						
                        <form role="form" method="post" action="">
                            <fieldset>
                               <p>
                                    <input placeholder="E-mail" value="<?php if(isset($_COOKIE["email"])){ echo $_COOKIE["email"];} ?>"name="email" type="email" autofocus>
                                </p>
                                <p>
                                    <input type="password" placeholder="Password" value="<?php if(isset($_COOKIE["password"])){ echo $_COOKIE["password"];} ?>" name="password" type="password">
                                </p>
                                 <p>
                                    <label>
                                       Remember Me  <input name="remember" type="checkbox" <?php if(isset($_COOKIE["email"])){ echo "checked";} ?>  value="remember"> 
                                    </label>
                                </p>
								 <p>
                                <input class="btn btn-lg btn-success btn-block" type="submit" name="submit" value="submit">
                                 </p>
								<!-- Change this to a button or input when using this as a form -->
                              
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
