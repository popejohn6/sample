<?php 
include '../config/dbconfig.php';
 require_once 'config.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  $chat =$obj->select("chat");
  
  if(isset($_REQUEST['submit']))
  {
      $type=$_REQUEST['type'];
       $fname=$_REQUEST['fname'];
        $sname=$_REQUEST['lname'];
        $email=$_REQUEST['email'];
        //$image=$_REQUEST['img'];
        $password=$fname.rand();
       
        $target_dir = "../upload/"; 
    $target_file = $target_dir . basename($_FILES["img"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    $img =basename($_FILES["img"]["name"]);
    if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
       
    } else {
       
    }

    $image=basename( $_FILES["img"]["name"],".jpg"); // used to store the filename in a variable
    
        $ins = "'','$fname','$sname','$email','$img','$password','$type'";
      $usr= $obj->insert_user("user",$ins);
        
       $msg="User add sucsessfuly";
              $msgen = urlencode(encryptor('encrypt', $msg));  
               header("location:adduser.php?msg=$msgen");
    
  $subject = "Test mail";
  $to_email = "udaymoradiya@gmail.com";
  $to_fullname = "John Doe";
  $from_email = "udaymoradiya@hotmail.com";
  $from_fullname = "Jane Doe";
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/html; charset=utf-8\r\n";
  // Additional headers
  // This might look redundant but some services REALLY favor it being there.
  $headers .= "To: $to_fullname <$to_email>\r\n";
  $headers .= "From: $from_fullname <$from_email>\r\n";
  $message = "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\">\r\n
  <head>\r\n
    <title>Hello Test</title>\r\n
  </head>\r\n
  <body>\r\n
    <p></p>\r\n
    <p style=\"color: #00CC66; font-weight:600; font-style: italic; font-size:14px; float:left; margin-left:7px;\">You have received an inquiry from your website.  Please review the contact information below.</p>\r\n
  </body>\r\n
  </html>";
  if (!mail($to_email, $subject, $message, $headers)) { 
    print_r(error_get_last());
  }
  else { ?>
   
  <?php
  }
  
        
  }
?>
<html lang="en" class="no-js">

<head>
    <link rel="stylesheet" type="text/css" href="../dist/css/component.css" />
		
		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
               
		
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  
     <script src="../bower_components/jquery/dist/jquery.min.js"></script>
      <script type="text/javascript" src="../js/notification.js"> </script>
       <script type="text/javascript" src="../js/campaign.js"> </script>
    <script type="text/javascript" src="../js/counter.js"></script>
    
    
<script src="../../dist/jquery.validate.js"></script>
<script>
	$(document).ready(function() {
		$("#commentForm").validate();
               
	});
	</script>
   
</head>

<body>
 
<div id='dd'> </div>
    <div id="morris-area-chart" hidden="true"></div>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="font-family: fantasy;font-size: 50px;color: #0075b0"><img src="logo.png" width="160px" height="30px"></img></a>
				
            </div>
            <!-- /.navbar-header -->

            <?php include 'header.php'; ?>
            <!-- /.navbar-top-links -->

            <?php include 'menu.php'; ?>
            <!-- /.navbar-static-side -->
        </nav>
        


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add User</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php 
                                     $msg="";
                                    if( isset($_GET['msg']) && !empty( $_GET['msg'] ) ){
                                        $msg = urldecode($_GET['msg']);
                                        $msg = encryptor('decrypt', $msg);
                                        ?>
                                        <script>
                                        setTimeout(function() {
                                        $('#mydiv').slideUp();
                                    }, 2000);
                                        </script>
                                         <div id="mydiv" class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                               <?php echo $msg; ?>
                                         </div>
                                         <?php
                                    }   
                        
                                    ?>     
           
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <snan>User</snan>
                             <div class="pull-right">
                                 <a href="viewuser.php" title="View User"> View User </a>
                            </div>
                        </div>
                        <center style='background-color: honeydew'> <br>
                            <form action="" method="post" enctype="multipart/form-data" id="commentForm">
                             
                             <table>
                                  <tr>
                                       <td><input type="radio" name="type" value="user" checked="true"> User
                                     <input type="radio" name="type" value="editor"> Editor
                                     </td>
                                 </tr>
                                 <tr>
                                       <td>  <input class="form-control" type="text" name="fname" placeholder="Enter User First Name " data-rule-required="true"  data-msg-required="Please Enter User First Name"> </td>
                                 </tr>
                                 <tr>
                                      <td> <input type="text" class="form-control" maxlength="50" name="lname" placeholder="Enter User Last Name " data-rule-required="true"  data-msg-required="Please Enter User Last Name"> </td>
                                 </tr>
                                  <tr>
                                      <td> <input type="email" class="form-control" name="email" placeholder="Enter User Email Address " data-rule-required="true" data-rule-email="true" data-msg-required="Please Enter User Email Address" data-msg-email="Please enter a valid email address"> </td>
                                 </tr>
                                 
                                  <tr>
                                      
                                     <td><input type="file" accept="image/*" name="img" id="img" class="inputfile inputfile-1"/>
					<label for="img"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg> <span>Choose a image &hellip;</span></label>
                                     </td>
                                 </tr>
                                
                                  <tr>
                                      
                                     <td><input class="btn btn-primary" type="submit" name="submit" value="Add User">
                                      <input class="btn btn-primary" type="reset" name="reset" value="clear">
                                     </td>
                                 </tr>
                                  
                                  <tr>
                                     <td></td>
                                     <td></td>
                                 </tr>
                             </table>
                       
                                  
                         </form><br>
                         
                        </center>
                        <!-- /.panel-heading -->
                      
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                   
                        <!-- /.panel-heading -->
                       
                                <!-- /.col-lg-4 (nested) -->
                               
                                <div id="morris-bar-chart" hidden="true"></div>
                               
                         
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    
                    <!-- /.panel -->
                   
                            <div id="morris-donut-chart" hidden="true"></div>
                           
                      
                    <!-- /.panel -->
                    
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../dist/js/custom-file-input.js"></script>
   

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>

<?php

}
else
{
    header("location:login.php");
}
?>
