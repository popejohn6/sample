<?php 
include '../config/dbconfig.php';
require_once 'config.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  $chat =$obj->select("chat");
  
   $user = $obj->select("user");
     $chanel = $obj->select("chanel");
     $band = $obj->select("brand");
     $audience = $obj->select("audience");
     
  if(isset($_REQUEST['submit']))
  {
      if(isset($_REQUEST['user'])=="")
      {
          $msg="Please Select user";
          $msgen = urlencode(encryptor('encrypt', $msg));  
           header("location:addcampaign.php?msg=$msgen");
           exit;
      }
     /* if(isset($_REQUEST['audience'])=="")
      {
          $msg="Please Select audience";
          $msgen = urlencode(encryptor('encrypt', $msg));  
           header("location:addcampaign.php?msg=$msgen");
           exit;
      }
      
     
       if(isset($_REQUEST['band'])=="")
      {
          $msg="Please Select band";
          $msgen = urlencode(encryptor('encrypt', $msg));  
           header("location:addcampaign.php?msg=$msgen");
           exit;
      }
       if(isset($_REQUEST['chanel'])=="")
      {
          $msg="Please Select channel";
          $msgen = urlencode(encryptor('encrypt', $msg));  
           header("location:addcampaign.php?msg=$msgen");
           exit;
      }*/
      $audience="";
      $band="";
      $chanel="";
      $cname=$_REQUEST['cname'];
       $sdate=$_REQUEST['sdate'];
        $edate=$_REQUEST['edate'];
        $audience=$_REQUEST['audience'];
        $chanel=$_REQUEST['chanel'];
        $band=$_REQUEST['band'];
        $user=$_REQUEST['user'];
        $priority=$_REQUEST['priority'];
        $detail=$_REQUEST['detail'];
        $private="yes";
        $creator =$row[2];
       $audi="";
        foreach ($audience as $aud) {
          $audi.=$aud.",";  
                   }
        $cha="";
        foreach ($chanel as $aud1) {
          $cha.=$aud1.",";  
           
        }
        $ban="";
        foreach ($band as $aud2) {
          $ban.=$aud2.",";  
           
        }
        
         $usr="";
          date_default_timezone_set('Asia/Kolkata');
         $time=time();
         $ctime= date('d-m-Y ');
        foreach ($user as $aud3) {
          $usr.=$aud3.",";  
          
           $notydata ="'','Added you to a campaign : $cname','unread','$ctime','$aud3',''";
         $usrnoty= $obj->insert_user("noty",$notydata);
           
        }
       
       
       $ins = "'','$usr','$cname','$sdate','$edate','$cha','$audi','$ban','$priority','$private','','','$detail','$creator','no','0'";
      
      $usr= $obj->insert_user("tasking",$ins);
      
         
           
     
       $msgen1 = urlencode(encryptor('encrypt', "Add Campaign Sucsessfuly"));  
      header("location:addcampaign.php?msg=$msgen1");
     
        
        
  }
?>
<html lang="en" class="no-js">

<head>
    <link rel="stylesheet" type="text/css" href="../dist/css/component.css" />
		
		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
               
		
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>
   <script src="../dist/js/jslib.js"></script>
      <script type="text/javascript" src="../js/notification.js"> </script>
        
    <script type="text/javascript" src="../js/counter.js"></script>
     <script type="text/javascript" src="../js/campaign.js"> </script>  
  
    <script src="../js/jquery-ui.js"></script>
 
        <!--pqSelect dependencies-->
        <link rel="stylesheet" href="pqselect.dev.css" />    
        <script src = "pqselect.dev.js"></script>
<script type="text/javascript">
            $(function() {
                
                //initialize the pqSelect widget.
                $("#select3").pqSelect({
                    multiplePlaceholder: 'Select Audience',
                    checkbox: true //adds checkbox to options    
                }).on("change", function(evt) {
                    var val = $(this).val();
                   //alert(val);
                });
                 $("#select4").pqSelect({
                    multiplePlaceholder: 'Select Channels',
                    checkbox: true //adds checkbox to options    
                }).on("change", function(evt) {
                    var val = $(this).val();
                   //alert(val);
                });
                 $("#select5").pqSelect({
                    multiplePlaceholder: 'Select Band',
                    checkbox: true //adds checkbox to options    
                }).on("change", function(evt) {
                    var val = $(this).val();
                   //alert(val);
                });
                 $("#select6").pqSelect({
                    multiplePlaceholder: 'Select User',
                    checkbox: true //adds checkbox to options    
                }).on("change", function(evt) {
                    var val = $(this).val();
                   //alert(val);
                });
            });
        </script> 
        
        
         <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

  
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    

    $("#datepicker").datepicker({
        
        minDate: 0,
        onSelect: function (date) {
            var date2 = $('#datepicker').datepicker('getDate');
            date2.setDate(date2.getDate() + 1);
            $('#datepicker2').datepicker('setDate', date2);
            //sets minDate to dt1 date + 1
            $('#datepicker2').datepicker('option', 'minDate', date2);
        }
    });
    $('#datepicker2').datepicker({
        
        onClose: function () {
            var dt1 = $('#datepicker').datepicker('getDate');
            var dt2 = $('#datepicker2').datepicker('getDate');
            //check to prevent a user from entering a date below date of dt1
            if (dt2 <= dt1) {
                var minDate = $('#datepicker2').datepicker('option', 'minDate');
                $('#datepicker2').datepicker('setDate', minDate);
            }
        }
    });

  });
  </script>

  <script src="../../dist/jquery.validate.js"></script>

</head>

<body>
   
 
    
<div id='dd'> </div>
    <div id="morris-area-chart" hidden="true"></div>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="font-family: fantasy;font-size: 50px;color: #0075b0"><img src="logo.png" width="160px" height="30px"></img></a>
				
            </div>
            <!-- /.navbar-header -->

            <?php include 'header.php'; ?>
            <!-- /.navbar-top-links -->

            <?php include 'menu.php'; ?>
            <!-- /.navbar-static-side -->
        </nav>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Campaign</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php 
                                     $msg="";
                                    if( isset($_GET['msg']) && !empty( $_GET['msg'] ) ){
                                        $msg = urldecode($_GET['msg']);
                                        $msg = encryptor('decrypt', $msg);
                                        ?>
                                          <script>
                                        setTimeout(function() {
                                        $('#mydiv').slideUp();
                                    }, 2000);
                                        </script>
                                        <div id="mydiv" class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                               <?php echo $msg; ?>
                                         </div>
                                         <?php
                                    }   
                        
                                    ?>     
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <snan>Campaign</snan>
                             <div class="pull-right">
                                 <a href="viewcampaign.php" title="View Campaign"> View Campaign </a>
                            </div>
                        </div>
                        <center style='background-color: honeydew'> <br>
                            <form action="" method="post" id="fm">
                             
                             <table>
                                  
                                 <tr>
                                     <td> <input type="text" class="form-control" name="cname" placeholder="Enter Campaign Name " data-rule-required="true"  data-msg-required="Please Enter Campaign Name"></td>
                                 </tr>
                                 <tr>
                                     <td>  <input type="text" class="form-control" id="datepicker"  name="sdate"  placeholder="Enter Start Date "  data-rule-required="true"  data-msg-required="Please Enter Start Date"></td>
                                 </tr>
                                  <tr>
                                      <td> <input type="text" class="form-control" id="datepicker2"  name="edate" placeholder="Enter End Date "  data-rule-required="true"  data-msg-required="Please Enter End Date"></td>
                                 </tr>
                                  <tr>
                                      <td>  
                                         
                                             <select id="select3" class="form-control" multiple=multiple name="audience[]" style="margin: 10px;width:200px;" >            

                                                   <?php 
                                                     while ($aud = mysql_fetch_array($audience)) {
                                                             
                                                                echo "<option value='".$aud[1]."'>".$aud[1]."</option>";
                                                                    
                                                                  
                                                                 
                                                                }
                                                                 
                                                    
                                                    ?>


                                            </select>
                                          </td>
                                 </tr>
                                 
                                 <tr>
                                      <td>  
                                         
                                             <select id="select4" class="form-control" multiple=multiple name="chanel[]" style="margin: 10px;width:200px;">            

                                                    <?php 
                                                     while ($cha = mysql_fetch_array($chanel)) {
                                                             
                                                                echo "<option value='".$cha[1]."'>".$cha[1]."</option>";
                                                                 
                                                                  
                                                                 
                                                                }
                                                                 
                                                    
                                                    ?>

                                            </select>
                                          </td>
                                 </tr>
                                 
                                 <tr>
                                      <td> 
                                         
                                             <select id="select5" class="form-control" multiple=multiple name="band[]" style="margin: 10px;width:200px;">            

                                                  <?php 
                                                     while ($ban = mysql_fetch_array($band)) {
                                                             
                                                                echo "<option value='".$ban[1]."'>".$ban[1]."</option>";
                                                                 
                                                                  
                                                                 
                                                                }
                                                                 
                                                    
                                                    ?>


                                            </select>
                                          </td>
                                 </tr>
                                 
                                 <tr>
                                      <td> 
                                         
                                             <select id="select6" class="form-control" multiple=multiple name="user[]" style="margin: 10px;width:200px;">            

                                                    <?php 
                                                     while ($users = mysql_fetch_array($user)) {
                                                             
                                                                 $userdata.="<option value='".$users[3]."'>".$users[3]."</option>";
                                                                 
                                                                  
                                                                 
                                                                }
                                                                echo $userdata;
                                                    
                                                    ?>
                                                   


                                            </select>
                                          </td>
                                 </tr>
                                 
                                 <tr>
                                      <td>  
                                         
                                          <select class="form-control" name="priority"  data-rule-required="true"  data-msg-required="Please Select Priority">            

                                                 <option value="">Select Priority</option>
                                                   <option>High</option>
                                                    <option>Medium</option>
                                                    <option>Low</option>


                                            </select>
                                          </td>
                                 </tr>
                                 
                                 <tr>
                                      <td> <textarea class="form-control" name="detail" placeholder="Enter Description " cols="22" data-rule-required="true"  data-msg-required="Please Enter Description "></textarea> </td>
                                 </tr>
                                 
                                  
                                 
                                
                                  <tr>
                                      
                                     <td><input class="btn btn-primary" style="background: #0088cc;color: #ffffff;" type="submit" name="submit" value="Add Campaign">
                                      <input class="btn btn-primary" style="background: #0088cc;color: #ffffff;" type="reset" name="reset" value="clear">
                                     </td>
                                 </tr>
                                  
                                  <tr>
                                     
                                     <td></td>
                                 </tr>
                             </table>
                       
                                  
                         </form><br>
                         
                        </center>
                        <!-- /.panel-heading -->
                      
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                   
                        <!-- /.panel-heading -->
                       
                                <!-- /.col-lg-4 (nested) -->
                               
                                <div id="morris-bar-chart" hidden="true"></div>
                               
                         
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    
                    <!-- /.panel -->
                   
                            <div id="morris-donut-chart" hidden="true"></div>
                           
                      
                    <!-- /.panel -->
                    
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../dist/js/custom-file-input.js"></script>
   <?php // <script src="../bower_components/jquery/dist/jquery.min.js"></script> ?>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
   <script>
		$(document).ready(function() {
			$("#fm").validate();
			 
		});
		</script>

</body>

</html>

<?php

}
else
{
    header("location:login.php");
}
?>
