<?php 
include '../config/dbconfig.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
   // $pass=0;
  //  $id = '';
  $row = mysql_fetch_array($tmp);
 // $chat =$obj->select("chat");
  $where = "uemail='$row[1]'";
    $mails= $obj->update_data("mail","status='read'",$where);
    
    header("location:index.php");
}

else
{
    header("location:login.php");
}