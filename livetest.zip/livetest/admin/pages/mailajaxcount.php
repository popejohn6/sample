<?php 
include '../config/dbconfig.php';
 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  $chat =$obj->select("chat");
  
   $noty= $obj->selectwhere("mail","status='unread'","uemail='$row[1]'");

  

  $chat =$obj->select("chat");
  $count = 0;
  $alrt="";
  while ($row1 = mysql_fetch_array($noty)) {
     
     
                $count = $count + 1;
          
  
    

     
      
  }
  
  // $alrt.="uday</ul>";
  if($count <=0)
  {
      $count='';
  }
   
     echo $count;
  
//echo json_encode(array("uday", $t));


   
   
   
       
}
else
{
    header("location:login.php");
}
?>
