<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <div>
                                <div style="padding-left:60px">
                                    <img style="width:70px;height:70px;border-radius: 60%;" alt="<?php echo $row['name']?>" src="../upload/<?php echo $row['image']?>"/> 
                               </div>
                                    <span class="navbar-brand" style="padding: 25px 15px;"> Welcome <?php echo $row['name']; ?> </span>
                                </div>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-user fa-fw"></i> User<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="adduser.php">Add User </a>
                                </li>
                                <li>
                                    <a href="viewuser.php">View User</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-tasks fa-fw"></i> Campaign<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addcampaign.php">Add Campaign </a>
                                </li>
                                <li>
                                    <a href="viewcampaign.php">View Campaign</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                        
                        <li>
                            <a href="#"><i class="fa fa-bell fa-fw"></i> ToDo's<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addtodo.php">Add ToDo's </a>
                                </li>
                                <li>
                                    <a href="viewtodo.php">View ToDo's</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bookmark fa-fw"></i> Channel<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addchannel.php">Add Channel </a>
                                </li>
                                <li>
                                    <a href="viewchannel.php">View Channel</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-empire fa-fw"></i> Band<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addband.php">Add Band </a>
                                </li>
                                <li>
                                    <a href="viewband.php">View Band</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level --> 
                        </li>
                         <li>
                            <a href="#"><i class="fa  fa-users  fa-fw"></i> Audience<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addaudience.php">Add Audience </a>
                                </li>
                                <li>
                                    <a href="viewaudience.php">View Audience</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level --> 
                        </li>
                         <li>
                            <a href="mail.php"><i class="fa fa-envelope fa-fw"></i> Mail</a>
                        </li>
                         
                        
                        
                                <li>
                                    <a href="setting.php"><i class="fa fa-gears fa-fw"></i>Setting</a>
                                </li>
                            
                            <!-- /.nav-second-level -->
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>