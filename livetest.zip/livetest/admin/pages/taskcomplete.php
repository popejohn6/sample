<?php 
include '../config/dbconfig.php';
require_once 'config.php';

 $obj->connect();
session_start();
if($_SESSION['id'] != '')
{
   $ar = $_SESSION['id'];
    $tmp= $obj->selectwhere("admin","id",$ar);
    $pass=0;
    $id = '';
  $row = mysql_fetch_array($tmp);
  $chat =$obj->select("chat");
  
   //$todocomplete =$obj->select("todos");
   $ar="";
   $alrt="";
   $tasklist=$obj->select("tasking");
   $taskreport="";
   /* while ($row2 = mysql_fetch_row($tasklist)) {
      
       // $todocomplate = $obj->updatecamp("tasking","status='0' Where id=$row1[1]");
       
        
        
    
   $qry ="SELECT * FROM todos where cid='$row2[0]'";
   $todocomplete =$obj->selectjoin($qry);

    while ($row1 = mysql_fetch_row($todocomplete)) {
      
         $ar.=$ar+1;
        $incom=0;
        $com=0;
        $finalcom=0;
        $total=0;
          $completetasklist ="SELECT * FROM todos where id='$row1[0]'";
            $completelist =$obj->selectjoin($completetasklist);
            while ($row3 = mysql_fetch_row($completelist)) {
                if($row3[8]=="")
                {
                    $incom=$incom+1;
                }
                else
                {
                    $com=$com+1;
                }
                
            }
            $total=$incom+$com;
                $finalcom= ($com/ $total) * 100;
                $taskreport.="$finalcom<br>";
       // $todocomplate = $obj->updatecamp("tasking","status='0' Where id=$row1[1]");
        $alrt.=" <a href='#' style='color: black;text-decoration: none;'> <div> <strong style='padding-left:05%'>".$row1[1]."</strong><span style='padding-right:10%;' class='pull-right text-muted small'>".$row1[5]."</span><span style='font-size:12px'; > <br><span style='padding-left:05%'>".$row1[2]."</span> </span> </div></a></li> <li class='divider'></li>";                               

        
    }
    
    }*/
   $todocomplete =$obj->select_where("todos","is_completed='yes'");
     while ($row1 = mysql_fetch_row($todocomplete)) {
        
        $todocomplate = $obj->updatecamp("tasking","status='0' Where id=$row1[1]");
        
    }
    
     $intodocomplete =$obj->select_where("todos","is_completed=''");
    
    while ($row1 = mysql_fetch_row($intodocomplete)) {
        
        $todocomplate = $obj->updatecamp("tasking","status='1' Where id=$row1[1]");
        
    }
     
    $data="";
    $taskreport="";
$list=$obj->selectjoin("SELECT * FROM todos group by cid ORDER BY id DESC");
while ($lst = mysql_fetch_row($list)) {
   $total=0;
   $incom=0;
   $com=0;
    
    $completetasklist ="SELECT * FROM todos where cid='$lst[1]'";
            $completelist =$obj->selectjoin($completetasklist);
            while ($row3 = mysql_fetch_row($completelist)) {
                if($row3[8]=="")
                {
                    $incom=$incom+1;
                }
                else
                {
                    $com=$com+1;
                }
                
            }
            $total=$incom+$com;
                $finalcom= ($com/ $total) * 100;
                $tmps= $obj->test("tasking","id",$lst[1]);
                 $row4 = mysql_fetch_array($tmps);
                if($finalcom!=100)
                {
                   $cid= urlencode(encryptor('encrypt', $row4[0]));  
                $taskreport.="<a style='text-decoration:none;' href='campaign_detail.php?id=$cid'><li style='margin: 10px;'><div> <p> <strong>$row4[2]</strong><span class='pull-right text-muted'>$finalcom % Complete</span></p><div class='progress progress-striped active'><div class='progress-bar progress-bar-success' role='progressbar' aria-valuenow='$finalcom' aria-valuemin='0' aria-valuemax='100' style='width: $finalcom%'><span class='sr-only'>$finalcom% Complete (success)</span></div></div></div></li> <li class='divider'></li></a>";
                $row4="";
                }
                
}
     
      
  
  
  // $alrt.="uday</ul>";
  
   
     echo $taskreport;
  
//echo json_encode(array("uday", $t));


   
   
   
       
}
else
{
    header("location:login.php");
}
?>
