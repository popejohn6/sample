
function addcount( count){
 
$('#count').html(count);
 $('#count2').html(count);
  $('#count3').html(count);
}
function waitForMsg2(){
 


$.ajax({
type: "GET",
url: "mailajaxcount.php",
 
async: true,
cache: false,
timeout:50000,
 
success: function(count){
   
addcount(count);
setTimeout(
waitForMsg2,
30000
);
},
error: function(XMLHttpRequest, textStatus, errorThrown){
addmsg("error", textStatus + " (" + errorThrown + ")");
setTimeout(
waitForMsg2,
15000);
}
});
};
 